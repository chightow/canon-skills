---
marp: true
theme: octave
paginate: true
html: true
---

<style>
@keyframes fadeUp {
  from { opacity: 0; transform: translateY(18px); }
  to   { opacity: 1; transform: translateY(0); }
}
.card { animation: fadeUp 0.35s both; }
.c1 { animation-delay: 0.05s; }
.c2 { animation-delay: 0.25s; }
.c3 { animation-delay: 0.45s; }
.c4 { animation-delay: 0.65s; }
.step { animation: fadeUp 0.3s both; }
.s1 { animation-delay: 0.05s; }
.s2 { animation-delay: 0.2s; }
.s3 { animation-delay: 0.35s; }
.s4 { animation-delay: 0.5s; }
.s5 { animation-delay: 0.65s; }
</style>

# Your Agent Shouldn't Grade Its Own Homework

*Why a fresh evaluator is not optional — it's structural*

---

## A thought experiment

<div style="display:grid; grid-template-columns:1fr 1fr; gap:18px; flex:1; min-height:0;">

  <div class="card c1" style="padding:28px 24px; background:rgba(0,255,255,0.07); border:1px solid rgba(0,255,255,0.25); border-radius:10px; display:flex; align-items:flex-start; gap:16px;">
    <span style="font-size:2.2em; font-weight:800; color:#00FFFF; line-height:1; flex-shrink:0;">1</span>
    <span style="font-size:0.95em; line-height:1.55;">You study for an exam.</span>
  </div>

  <div class="card c2" style="padding:28px 24px; background:rgba(79,255,0,0.07); border:1px solid rgba(79,255,0,0.25); border-radius:10px; display:flex; align-items:flex-start; gap:16px;">
    <span style="font-size:2.2em; font-weight:800; color:#4FFF00; line-height:1; flex-shrink:0;">2</span>
    <span style="font-size:0.95em; line-height:1.55;">You take the exam.</span>
  </div>

  <div class="card c3" style="padding:28px 24px; background:rgba(255,245,0,0.07); border:1px solid rgba(255,245,0,0.25); border-radius:10px; display:flex; align-items:flex-start; gap:16px;">
    <span style="font-size:2.2em; font-weight:800; color:#FFF500; line-height:1; flex-shrink:0;">3</span>
    <span style="font-size:0.95em; line-height:1.55;">You grade your own exam.</span>
  </div>

  <div class="card c4" style="padding:28px 24px; background:rgba(244,102,0,0.12); border:2px solid #F46600; border-radius:10px; display:flex; align-items:flex-start; gap:16px;">
    <span style="font-size:2.2em; font-weight:800; color:#F46600; line-height:1; flex-shrink:0;">?</span>
    <span style="font-size:0.88em; line-height:1.6;">Does your grade reflect what you actually got right — or what you <em>think</em> you got right?</span>
  </div>

</div>

---

## This is exactly what self-eval does

<div style="display:flex; gap:20px; flex:1; min-height:0;">

  <!-- Left column: what you think -->
  <div style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(0,255,255,0.25);">
    <div style="padding:12px 18px; background:rgba(0,255,255,0.15); font-size:0.68em; text-transform:uppercase; letter-spacing:0.09em; color:#00FFFF; font-weight:600;">What you think is happening</div>
    <div style="flex:1; padding:16px; display:flex; flex-direction:column; align-items:center; justify-content:space-evenly; gap:4px; background:rgba(62,64,71,0.25);">
      <div class="step s1" style="width:100%; padding:10px 14px; background:rgba(0,255,255,0.08); border-radius:6px; font-size:0.8em; text-align:center;">Agent builds feature</div>
      <svg width="20" height="20" viewBox="0 0 20 20" style="flex-shrink:0;"><path d="M10 2 L10 14 M4 10 L10 16 L16 10" stroke="#00FFFF" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <div class="step s2" style="width:100%; padding:10px 14px; background:rgba(0,255,255,0.08); border-radius:6px; font-size:0.8em; text-align:center;">Agent reviews its own work</div>
      <svg width="20" height="20" viewBox="0 0 20 20" style="flex-shrink:0;"><path d="M10 2 L10 14 M4 10 L10 16 L16 10" stroke="#00FFFF" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <div class="step s3" style="width:100%; padding:10px 14px; background:rgba(0,255,255,0.08); border-radius:6px; font-size:0.8em; text-align:center;">Agent says "looks good"</div>
      <svg width="20" height="20" viewBox="0 0 20 20" style="flex-shrink:0;"><path d="M10 2 L10 14 M4 10 L10 16 L16 10" stroke="#4FFF00" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <div class="step s4" style="width:100%; padding:10px 14px; background:rgba(79,255,0,0.15); border:1px solid rgba(79,255,0,0.4); border-radius:6px; font-size:0.82em; text-align:center; font-weight:700; color:#4FFF00;">Ship it ✓</div>
    </div>
  </div>

  <!-- Right column: what's actually happening -->
  <div style="flex:1; display:flex; flex-direction:column; border-radius:10px; overflow:hidden; border:1px solid rgba(255,0,199,0.25);">
    <div style="padding:12px 18px; background:rgba(255,0,199,0.15); font-size:0.68em; text-transform:uppercase; letter-spacing:0.09em; color:#FF00C7; font-weight:600;">What's actually happening</div>
    <div style="flex:1; padding:16px; display:flex; flex-direction:column; align-items:center; justify-content:space-evenly; gap:4px; background:rgba(62,64,71,0.25);">
      <div class="step s1" style="width:100%; padding:10px 14px; background:rgba(255,0,199,0.08); border-radius:6px; font-size:0.8em; text-align:center;">Agent builds feature</div>
      <svg width="20" height="20" viewBox="0 0 20 20" style="flex-shrink:0;"><path d="M10 2 L10 14 M4 10 L10 16 L16 10" stroke="#FF00C7" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <div class="step s2" style="width:100%; padding:10px 14px; background:rgba(255,0,199,0.08); border-radius:6px; font-size:0.8em; text-align:center;">Same context. Same assumptions.</div>
      <svg width="20" height="20" viewBox="0 0 20 20" style="flex-shrink:0;"><path d="M10 2 L10 14 M4 10 L10 16 L16 10" stroke="#F46600" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <div class="step s3" style="width:100%; padding:10px 14px; background:rgba(244,102,0,0.12); border-radius:6px; font-size:0.8em; text-align:center;">Same blind spots.</div>
      <svg width="20" height="20" viewBox="0 0 20 20" style="flex-shrink:0;"><path d="M10 2 L10 14 M4 10 L10 16 L16 10" stroke="#F46600" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
      <div class="step s4" style="width:100%; padding:10px 14px; background:rgba(244,102,0,0.2); border:1px solid rgba(244,102,0,0.5); border-radius:6px; font-size:0.82em; text-align:center; font-weight:700; color:#F46600;">Misses the same bugs ✗</div>
    </div>
  </div>

</div>

---

## Context contamination

<div style="display:grid; grid-template-rows:auto 1fr auto; flex:1; min-height:0; gap:10px;">

<div style="font-size:0.88em; color:#B2B8C4; line-height:1.5;">By the time your agent reaches eval, its context looks like this:</div>

<div style="display:flex; flex-direction:column; justify-content:space-between; min-height:0;">
  <div class="step s1" style="display:flex; align-items:center; gap:14px;">
    <div style="width:110px; font-size:0.65em; color:#00FFFF; text-align:right; font-weight:600;">Session start</div>
    <div style="flex:1; height:38px; background:rgba(0,255,255,0.12); border:1px solid rgba(0,255,255,0.3); border-radius:4px; display:flex; align-items:center; padding:0 12px; font-size:0.62em; color:#00FFFF;">system + tools + task</div>
  </div>
  <div class="step s2" style="display:flex; align-items:center; gap:14px;">
    <div style="width:110px; font-size:0.65em; color:#4FFF00; text-align:right; font-weight:600;">Orient</div>
    <div style="flex:1; height:38px; background:rgba(79,255,0,0.1); border:1px solid rgba(79,255,0,0.25); border-radius:4px; display:flex; align-items:center; padding:0 12px; font-size:0.62em; color:#4FFF00;">+ codebase reads, grep outputs, file trees</div>
  </div>
  <div class="step s3" style="display:flex; align-items:center; gap:14px;">
    <div style="width:110px; font-size:0.65em; color:#FFF500; text-align:right; font-weight:600;">Plan</div>
    <div style="flex:1; height:38px; background:rgba(255,245,0,0.1); border:1px solid rgba(255,245,0,0.2); border-radius:4px; display:flex; align-items:center; padding:0 12px; font-size:0.62em; color:#FFF500;">+ assumptions, decisions, plan.md</div>
  </div>
  <div class="step s4" style="display:flex; align-items:center; gap:14px;">
    <div style="width:110px; font-size:0.65em; color:#F46600; text-align:right; font-weight:600;">Build</div>
    <div style="flex:1; height:38px; background:rgba(244,102,0,0.12); border:1px solid rgba(244,102,0,0.3); border-radius:4px; display:flex; align-items:center; padding:0 12px; font-size:0.62em; color:#F46600;">+ every edit, test run, error, retry, workaround</div>
  </div>
  <div class="step s5" style="display:flex; align-items:center; gap:14px;">
    <div style="width:110px; font-size:0.65em; color:#FF00C7; text-align:right; font-weight:700;">↓ Eval here</div>
    <div style="flex:1; height:44px; background:rgba(255,0,199,0.14); border:2px solid #FF00C7; border-radius:4px; display:flex; align-items:center; padding:0 12px; font-size:0.65em; color:#FF00C7; font-weight:600;">evaluating with the full memory of everything it just did</div>
  </div>
</div>

<blockquote style="font-size:0.82em;">The agent knows why it made every decision. It can't un-know that when grading.</blockquote>

</div>

---

## The 60% problem

<div style="display:flex; gap:48px; align-items:stretch; flex:1; min-height:0;">

  <!-- Diagram column -->
  <div style="width:260px; flex-shrink:0; display:flex; flex-direction:column; gap:5px;">
    <div class="step s1" style="background:#3E4047; border:1px solid #6F7480; padding:13px 16px; font-size:0.72em; color:#B2B8C4; border-radius:4px; text-align:center;">System Instructions + CLAUDE.md</div>
    <div class="step s1" style="background:#3E4047; border:1px solid #6F7480; padding:13px 16px; font-size:0.72em; color:#B2B8C4; border-radius:4px; text-align:center;">Builtin Tools + MCP Schemas</div>
    <div class="step s2" style="background:#1d4a2a; border:2px solid #4FFF00; padding:13px 16px; font-size:0.72em; color:#4FFF00; border-radius:4px; text-align:center; font-weight:600;">User message</div>
    <div class="step s3" style="flex:1; background:rgba(0,255,255,0.07); border:2px dashed #00FFFF; border-radius:4px; display:flex; flex-direction:column; justify-content:center; align-items:center; text-align:center; gap:6px;">
      <span style="font-size:0.85em; font-weight:700; color:#00FFFF;">"the smart zone"</span>
      <span style="font-size:0.7em; color:#6F7480;">~60% of your window</span>
    </div>
    <div class="step s4" style="background:rgba(244,102,0,0.22); border:1px solid #F46600; padding:11px 16px; border-radius:4px; display:flex; justify-content:space-between; align-items:center;">
      <span style="font-size:1em; font-weight:800; color:#F46600;">23k</span>
      <span style="font-size:0.68em; color:#F46600;">auto-compact</span>
    </div>
    <div class="step s4" style="background:rgba(255,0,199,0.22); border:1px solid #FF00C7; padding:11px 16px; border-radius:4px; display:flex; justify-content:space-between; align-items:center;">
      <span style="font-size:1em; font-weight:800; color:#FF00C7;">32k</span>
      <span style="font-size:0.68em; color:#FF00C7;">output</span>
    </div>
  </div>

  <div style="flex:1; display:flex; flex-direction:column; justify-content:center; gap:20px;">
    <div class="card c1" style="padding:20px 22px; background:rgba(62,64,71,0.35); border-radius:8px; font-size:0.88em; line-height:1.6;">
      You start a session with <em>at most 60%</em> of your window as working space.
    </div>
    <div class="card c2" style="padding:20px 22px; background:rgba(62,64,71,0.35); border-radius:8px; font-size:0.88em; line-height:1.6;">
      After a full sprint — orient, plan, build, test — that zone is <strong>dense with implementation history.</strong>
    </div>
    <div class="card c3" style="padding:20px 22px; background:rgba(255,0,199,0.08); border:1px solid rgba(255,0,199,0.3); border-radius:8px; font-size:0.85em; line-height:1.6;">
      Asking the agent to eval now is asking it to judge with a context full of its own rationalizations.
    </div>
  </div>

</div>

---

## Three failure modes

<div style="display:flex; flex-direction:column; justify-content:space-between; flex:1; min-height:0;">

  <div class="card c1" style="display:flex; gap:20px; padding:20px 24px; background:rgba(62,64,71,0.35); border-left:4px solid #F46600; border-radius:0 10px 10px 0; align-items:flex-start;">
    <div style="font-size:1.8em; flex-shrink:0; line-height:1;">🎯</div>
    <div>
      <div style="color:#F46600; font-weight:700; font-size:0.95em; margin-bottom:5px;">Anchoring</div>
      <div style="font-size:0.82em; line-height:1.55; color:#B2B8C4;">The agent remembers why it made each decision. It grades against its own reasoning, not the acceptance criteria. <em>"I meant to do it this way"</em> reads as pass.</div>
    </div>
  </div>

  <div class="card c2" style="display:flex; gap:20px; padding:20px 24px; background:rgba(62,64,71,0.35); border-left:4px solid #FFF500; border-radius:0 10px 10px 0; align-items:flex-start;">
    <div style="font-size:1.8em; flex-shrink:0; line-height:1;">🎰</div>
    <div>
      <div style="color:#FFF500; font-weight:700; font-size:0.95em; margin-bottom:5px;">Reward hacking</div>
      <div style="font-size:0.82em; line-height:1.55; color:#B2B8C4;">Optimizing to pass the eval it wrote, not to actually meet the goal. Self-written acceptance criteria + self-grader = circular success.</div>
    </div>
  </div>

  <div class="card c3" style="display:flex; gap:20px; padding:20px 24px; background:rgba(62,64,71,0.35); border-left:4px solid #FF00C7; border-radius:0 10px 10px 0; align-items:flex-start;">
    <div style="font-size:1.8em; flex-shrink:0; line-height:1;">🕳️</div>
    <div>
      <div style="color:#FF00C7; font-weight:700; font-size:0.95em; margin-bottom:5px;">Shared blind spots</div>
      <div style="font-size:0.82em; line-height:1.55; color:#B2B8C4;">If the implementation made a wrong assumption, the eval inherits it. The same hallucination that created the bug will miss it in review.</div>
    </div>
  </div>

</div>

---

## What a biased eval looks like

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:14px;">
<pre style="font-size:0.76em; margin:0; overflow:auto;"><code>## Criteria
| Criterion                         | Status  | Evidence                          |
|-----------------------------------|---------|-----------------------------------|
| handles empty input gracefully    | pass    | looks like it should work         |
| returns error on invalid schema   | pass    | probably covered by the try/catch |
| logs structured output            | partial | I intended to add this            |</code></pre>

<div style="display:flex; gap:16px;">
  <div class="card c1" style="flex:1; padding:16px 18px; background:rgba(244,102,0,0.1); border-left:3px solid #F46600; border-radius:0 8px 8px 0; font-size:0.8em; line-height:1.5;">
    <strong style="color:#F46600;">"looks like it should work"</strong><br>
    <span style="color:#6F7480;">Not evidence. A guess from someone who wants to ship.</span>
  </div>
  <div class="card c2" style="flex:1; padding:16px 18px; background:rgba(244,102,0,0.1); border-left:3px solid #FF00C7; border-radius:0 8px 8px 0; font-size:0.8em; line-height:1.5;">
    <strong style="color:#FF00C7;">"I intended to add this"</strong><br>
    <span style="color:#6F7480;">Intent isn't implementation. Fail dressed as partial.</span>
  </div>
</div>
</div>

---

## The fix: generator–evaluator separation

<div style="display:flex; flex-direction:column; flex:1; min-height:0; gap:20px;">
<div style="display:flex; align-items:stretch; flex:1; gap:0;">
<div class="card c1" style="flex:1; padding:28px; background:rgba(0,255,255,0.07); border:1px solid rgba(0,255,255,0.3); border-radius:10px 0 0 10px; display:flex; flex-direction:column; justify-content:center; text-align:center; gap:12px;">
<div style="font-size:0.65em; color:#00FFFF; text-transform:uppercase; letter-spacing:0.1em; font-weight:600;">Generator</div>
<div style="font-size:0.88em; color:#B2B8C4; line-height:1.6;">Builds the feature<br>Full sprint history<br>Knows every decision</div>
</div>
<div style="display:flex; flex-direction:column; align-items:center; justify-content:center; width:120px; flex-shrink:0; gap:10px;">
<div style="font-size:0.6em; color:#6F7480; text-align:center; line-height:1.5;">acceptance.md<br>changed files</div>
<svg width="60" height="20" viewBox="0 0 60 20"><path d="M2 10 L50 10" stroke="#9933FF" stroke-width="2.5" fill="none" stroke-linecap="round"/><path d="M43 4 L54 10 L43 16" stroke="#9933FF" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>
</div>
<div class="card c2" style="flex:1; padding:28px; background:rgba(153,51,255,0.1); border:1px solid rgba(153,51,255,0.4); border-radius:0 10px 10px 0; display:flex; flex-direction:column; justify-content:center; text-align:center; gap:12px;">
<div style="font-size:0.65em; color:#9933FF; text-transform:uppercase; letter-spacing:0.1em; font-weight:600;">Evaluator</div>
<div style="font-size:0.88em; color:#B2B8C4; line-height:1.6;"><strong>Fresh context</strong><br>No implementation memory<br>Adversarial by default</div>
</div>
</div>
<div class="card c3" style="padding:20px 24px; background:rgba(153,51,255,0.08); border-left:3px solid #9933FF; border-radius:0 8px 8px 0; font-size:0.88em; line-height:1.6;">
The evaluator only sees what was <strong>promised</strong> (<code>acceptance.md</code>) and what <strong>shipped</strong> (changed files). It cannot rationalize the gap.
</div>
</div>

---

## What "clean context" actually means

<div style="display:flex; gap:20px; flex:1; min-height:0;">

  <div class="card c1" style="flex:1; padding:24px; background:rgba(244,102,0,0.07); border:1px solid rgba(244,102,0,0.25); border-radius:10px;">
    <div style="font-size:0.65em; color:#F46600; text-transform:uppercase; letter-spacing:0.09em; margin-bottom:16px; font-weight:600;">Evaluator cannot see</div>
    <div style="display:flex; flex-direction:column; gap:10px;">
      <div class="step s1" style="display:flex; gap:10px; align-items:center; font-size:0.82em;"><span style="color:#F46600; font-size:1.1em;">✗</span> The sprint conversation</div>
      <div class="step s2" style="display:flex; gap:10px; align-items:center; font-size:0.82em;"><span style="color:#F46600; font-size:1.1em;">✗</span> Intermediate file reads</div>
      <div class="step s3" style="display:flex; gap:10px; align-items:center; font-size:0.82em;"><span style="color:#F46600; font-size:1.1em;">✗</span> Errors and retries during build</div>
      <div class="step s4" style="display:flex; gap:10px; align-items:center; font-size:0.82em;"><span style="color:#F46600; font-size:1.1em;">✗</span> The agent's own reasoning</div>
      <div class="step s5" style="display:flex; gap:10px; align-items:center; font-size:0.82em;"><span style="color:#F46600; font-size:1.1em;">✗</span> Files NOT in the changed list</div>
    </div>
  </div>

  <div class="card c2" style="flex:1; padding:24px; background:rgba(0,255,255,0.06); border:1px solid rgba(0,255,255,0.25); border-radius:10px;">
    <div style="font-size:0.65em; color:#00FFFF; text-transform:uppercase; letter-spacing:0.09em; margin-bottom:16px; font-weight:600;">Evaluator can only see</div>
    <div style="display:flex; flex-direction:column; gap:12px;">
      <div class="step s1" style="padding:12px 14px; background:rgba(0,255,255,0.08); border-radius:6px; font-size:0.82em; line-height:1.4;"><code>acceptance.md</code> — what was promised</div>
      <div class="step s2" style="padding:12px 14px; background:rgba(0,255,255,0.08); border-radius:6px; font-size:0.82em; line-height:1.4;"><code>plan.md</code> — approved approach</div>
      <div class="step s3" style="padding:12px 14px; background:rgba(0,255,255,0.08); border-radius:6px; font-size:0.82em; line-height:1.4;">Changed files — what actually shipped</div>
    </div>
    <div style="margin-top:16px; font-size:0.76em; color:#6F7480;">That's it. No shortcuts.</div>
  </div>

</div>

---

## Canon's eval skill

<div style="display:grid; grid-template-rows:auto 1fr auto; flex:1; min-height:0; gap:12px;">
<div style="font-size:0.84em; color:#B2B8C4;">Called automatically by <code>sprint complete</code>. You do not invoke it directly.</div>

<pre style="font-size:0.78em; margin:0; overflow:auto;"><code>You are an evaluator agent.
You did NOT write the code under review.
You have no implementation history —
only the ticket artifacts and the changed files.</code></pre>

<div style="display:flex; gap:14px;">
  <div class="card c1" style="flex:1; padding:16px; background:rgba(0,255,255,0.07); border:1px solid rgba(0,255,255,0.25); border-radius:8px; font-size:0.82em; line-height:1.5; text-align:center;">
    <div style="font-size:1.3em; margin-bottom:6px;">✅</div>
    <strong style="color:#00FFFF;">pass</strong><br>
    <span style="color:#6F7480; font-size:0.9em;">evidence confirms; cite <code>file:line</code></span>
  </div>
  <div class="card c2" style="flex:1; padding:16px; background:rgba(244,102,0,0.08); border:1px solid rgba(244,102,0,0.25); border-radius:8px; font-size:0.82em; line-height:1.5; text-align:center;">
    <div style="font-size:1.3em; margin-bottom:6px;">❌</div>
    <strong style="color:#F46600;">fail</strong><br>
    <span style="color:#6F7480; font-size:0.9em;">not met or contradicted; cite what was found</span>
  </div>
  <div class="card c3" style="flex:1; padding:16px; background:rgba(255,245,0,0.07); border:1px solid rgba(255,245,0,0.25); border-radius:8px; font-size:0.82em; line-height:1.5; text-align:center;">
    <div style="font-size:1.3em; margin-bottom:6px;">⚠️</div>
    <strong style="color:#FFF500;">partial</strong><br>
    <span style="color:#6F7480; font-size:0.9em;">treated as fail at sprint close</span>
  </div>
</div>
</div>

---

## Weak evidence — the evaluator rejects these

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:12px;">
<div style="display:flex; flex-direction:column; justify-content:space-between; min-height:0;">
  <div class="card c1" style="display:flex; gap:14px; align-items:center; padding:13px 18px; background:rgba(244,102,0,0.08); border-radius:8px; font-size:0.82em; line-height:1.4;">
    <span style="color:#F46600; font-size:1.2em; flex-shrink:0;">✗</span>
    <span><em>"looks good"</em> / <em>"seems covered"</em> / <em>"probably works"</em></span>
  </div>
  <div class="card c2" style="display:flex; gap:14px; align-items:center; padding:13px 18px; background:rgba(244,102,0,0.08); border-radius:8px; font-size:0.82em; line-height:1.4;">
    <span style="color:#F46600; font-size:1.2em; flex-shrink:0;">✗</span>
    <span>A citation that doesn't point to a changed file</span>
  </div>
  <div class="card c3" style="display:flex; gap:14px; align-items:center; padding:13px 18px; background:rgba(244,102,0,0.08); border-radius:8px; font-size:0.82em; line-height:1.4;">
    <span style="color:#F46600; font-size:1.2em; flex-shrink:0;">✗</span>
    <span>A runtime check that was required but not run</span>
  </div>
  <div class="card c4" style="display:flex; gap:14px; align-items:center; padding:13px 18px; background:rgba(244,102,0,0.08); border-radius:8px; font-size:0.82em; line-height:1.4;">
    <span style="color:#F46600; font-size:1.2em; flex-shrink:0;">✗</span>
    <span>A stale cached value without timestamp + freshness window</span>
  </div>
  <div class="card c5" style="display:flex; gap:14px; align-items:center; padding:13px 18px; background:rgba(244,102,0,0.08); border-radius:8px; font-size:0.82em; line-height:1.4;">
    <span style="color:#F46600; font-size:1.2em; flex-shrink:0;">✗</span>
    <span>Generated output that was never inspected</span>
  </div>
</div>

<blockquote style="font-size:0.82em;">If you can't point to the code, it's a fail.</blockquote>
</div>

---

## Three layers of evaluation

<div style="display:grid; grid-template-rows:1fr auto; flex:1; min-height:0; gap:12px;">
<div style="display:flex; flex-direction:column; justify-content:space-between; min-height:0;">

  <div class="card c1" style="display:flex; gap:20px; padding:18px 24px; background:rgba(0,255,255,0.07); border:1px solid rgba(0,255,255,0.25); border-radius:10px; align-items:center;">
    <div style="font-size:1.6em; font-weight:800; color:#00FFFF; line-height:1; flex-shrink:0; min-width:36px; text-align:center;">L1</div>
    <div style="flex:1;">
      <div style="display:flex; align-items:baseline; gap:10px; margin-bottom:4px;">
        <span style="font-size:0.85em; font-weight:700; color:#00FFFF;">Binary checks</span>
        <span style="font-size:0.6em; color:#6F7480; text-transform:uppercase; letter-spacing:0.06em;">Deterministic</span>
      </div>
      <div style="font-size:0.78em; color:#B2B8C4; line-height:1.5;">File exists, test passes, field non-null, exit code 0. Run once. Never flaky. Always the first gate.</div>
    </div>
    <div style="font-size:0.65em; color:#4FFF00; white-space:nowrap; flex-shrink:0;">Run 1×</div>
  </div>

  <div class="card c2" style="display:flex; gap:20px; padding:18px 24px; background:rgba(153,51,255,0.07); border:1px solid rgba(153,51,255,0.25); border-radius:10px; align-items:center;">
    <div style="font-size:1.6em; font-weight:800; color:#9933FF; line-height:1; flex-shrink:0; min-width:36px; text-align:center;">L2</div>
    <div style="flex:1;">
      <div style="display:flex; align-items:baseline; gap:10px; margin-bottom:4px;">
        <span style="font-size:0.85em; font-weight:700; color:#9933FF;">LLM-as-judge</span>
        <span style="font-size:0.6em; color:#6F7480; text-transform:uppercase; letter-spacing:0.06em;">Semantic</span>
      </div>
      <div style="font-size:0.78em; color:#B2B8C4; line-height:1.5;">Does the output meet the criterion? Probabilistic — run 3× and majority-vote. This is the evaluator pattern in this deck.</div>
    </div>
    <div style="font-size:0.65em; color:#FFF500; white-space:nowrap; flex-shrink:0;">Run 3× / vote</div>
  </div>

  <div class="card c3" style="display:flex; gap:20px; padding:18px 24px; background:rgba(244,102,0,0.07); border:1px solid rgba(244,102,0,0.25); border-radius:10px; align-items:center;">
    <div style="font-size:1.6em; font-weight:800; color:#F46600; line-height:1; flex-shrink:0; min-width:36px; text-align:center;">L3</div>
    <div style="flex:1;">
      <div style="display:flex; align-items:baseline; gap:10px; margin-bottom:4px;">
        <span style="font-size:0.85em; font-weight:700; color:#F46600;">End-to-end in production conditions</span>
        <span style="font-size:0.6em; color:#6F7480; text-transform:uppercase; letter-spacing:0.06em;">Behavioural</span>
      </div>
      <div style="font-size:0.78em; color:#B2B8C4; line-height:1.5;">Real user flows, real infrastructure, real failure modes. Expensive to build and run. Use for the paths that matter most.</div>
    </div>
    <div style="font-size:0.65em; color:#F46600; white-space:nowrap; flex-shrink:0;">Run sparingly</div>
  </div>

</div>

</div>
<div style="padding:10px 16px; background:rgba(153,51,255,0.06); border-left:3px solid #9933FF; border-radius:0 8px 8px 0; font-size:0.78em; color:#B2B8C4;">
The eval subagent in this deck operates at <strong style="color:#9933FF;">L2</strong>. L1 gates run first. L3 needs to be wired at build time — it can't be retrofitted.
</div>
</div>

---

## The sprint → eval pipeline

<div style="display:flex; justify-content:center; align-items:center; flex:1; min-height:0;">
<div style="display:flex; flex-direction:column; align-items:center; gap:0; width:100%; max-width:580px;">

  <div class="step s1" style="width:100%; padding:14px 20px; background:rgba(0,255,255,0.08); border:1px solid rgba(0,255,255,0.3); border-radius:8px; text-align:center; font-size:0.82em;"><code>sprint start</code> — creates ticket + acceptance.md + plan.md</div>

  <svg width="20" height="28" viewBox="0 0 20 28" style="flex-shrink:0;"><path d="M10 2 L10 22 M4 16 L10 24 L16 16" stroke="#3E4047" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>

  <div class="step s2" style="width:100%; padding:14px 20px; background:rgba(62,64,71,0.4); border-radius:8px; text-align:center; font-size:0.82em; color:#B2B8C4;">Implementation — generator agent, full sprint context</div>

  <svg width="20" height="28" viewBox="0 0 20 28" style="flex-shrink:0;"><path d="M10 2 L10 22 M4 16 L10 24 L16 16" stroke="#3E4047" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>

  <div class="step s3" style="width:100%; padding:14px 20px; background:rgba(0,255,255,0.08); border:1px solid rgba(0,255,255,0.3); border-radius:8px; text-align:center; font-size:0.82em;"><code>sprint complete</code> — triggers eval automatically</div>

  <svg width="20" height="28" viewBox="0 0 20 28" style="flex-shrink:0;">
    <path d="M10 2 L10 22 M4 16 L10 24 L16 16" stroke="#9933FF" stroke-width="2.5" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  </svg>

  <div class="step s4" style="width:100%; padding:14px 20px; background:rgba(153,51,255,0.15); border:1px solid rgba(153,51,255,0.4); border-radius:8px; text-align:center; font-size:0.82em; color:#9933FF; font-weight:600;">Eval subagent — <strong>fresh context</strong> only: acceptance.md + changed files</div>

  <svg width="20" height="28" viewBox="0 0 20 28" style="flex-shrink:0;"><path d="M10 2 L10 22 M4 16 L10 24 L16 16" stroke="#4FFF00" stroke-width="2" fill="none" stroke-linecap="round" stroke-linejoin="round"/></svg>

  <div class="step s5" style="width:100%; padding:14px 20px; background:rgba(79,255,0,0.08); border:1px solid rgba(79,255,0,0.3); border-radius:8px; text-align:center; font-size:0.82em; color:#4FFF00;"><code>eval-report.md</code> — pass / fail / partial per criterion, with evidence</div>

</div>
</div>

---

## Gotchas

<div style="display:flex; flex-direction:column; justify-content:space-between; flex:1; min-height:0;">

  <div class="card c1" style="padding:16px 20px; background:rgba(62,64,71,0.35); border-left:4px solid #F46600; border-radius:0 8px 8px 0; font-size:0.84em; line-height:1.5;">
    <strong style="color:#F46600;">Evaluator prompt creep</strong> — adding "helpful context" to the eval prompt re-contaminates the clean context. The restriction is the point.
  </div>

  <div class="card c2" style="padding:16px 20px; background:rgba(62,64,71,0.35); border-left:4px solid #FFF500; border-radius:0 8px 8px 0; font-size:0.84em; line-height:1.5;">
    <strong style="color:#FFF500;">Eval-skipping under pressure</strong> — <em>"it's a small fix."</em> The bugs that hurt most come from the fixes that felt obvious.
  </div>

  <div class="card c3" style="padding:16px 20px; background:rgba(62,64,71,0.35); border-left:4px solid #FF00C7; border-radius:0 8px 8px 0; font-size:0.84em; line-height:1.5;">
    <strong style="color:#FF00C7;">Partial ≠ soft pass</strong> — canon treats partials the same as fails at sprint close. <em>"Mostly done"</em> is not done.
  </div>

  <div class="card c4" style="padding:16px 20px; background:rgba(62,64,71,0.35); border-left:4px solid #9933FF; border-radius:0 8px 8px 0; font-size:0.84em; line-height:1.5;">
    <strong style="color:#9933FF;">Empty acceptance.md</strong> — an eval against no criteria auto-fails. Writing good criteria is half the quality system.
  </div>

  <div class="card c5" style="padding:16px 20px; background:rgba(62,64,71,0.35); border-left:4px solid #4FFF00; border-radius:0 8px 8px 0; font-size:0.84em; line-height:1.5;">
    <strong style="color:#4FFF00;">No owner for the eval suite</strong> — a suite with no owner drifts silently. Assign a human. Tie eval review to the sprint cadence, not the next incident.
  </div>

</div>

---

## Four rules

<div style="display:flex; flex-direction:column; justify-content:space-between; flex:1; min-height:0;">

  <div class="card c1" style="display:flex; gap:22px; align-items:center; padding:18px 28px; background:rgba(62,64,71,0.35); border-radius:10px;">
    <div style="font-size:2em; font-weight:800; color:#00FFFF; min-width:40px; line-height:1; flex-shrink:0;">1</div>
    <div style="font-size:0.88em; line-height:1.55;"><strong>Separate generator from evaluator.</strong> Never the same context, never the same agent instance.</div>
  </div>

  <div class="card c2" style="display:flex; gap:22px; align-items:center; padding:18px 28px; background:rgba(62,64,71,0.35); border-radius:10px;">
    <div style="font-size:2em; font-weight:800; color:#9933FF; min-width:40px; line-height:1; flex-shrink:0;">2</div>
    <div style="font-size:0.88em; line-height:1.55;"><strong>Clean context is not a preference.</strong> It's what makes the eval structurally capable of catching errors.</div>
  </div>

  <div class="card c3" style="display:flex; gap:22px; align-items:center; padding:18px 28px; background:rgba(62,64,71,0.35); border-radius:10px;">
    <div style="font-size:2em; font-weight:800; color:#4FFF00; min-width:40px; line-height:1; flex-shrink:0;">3</div>
    <div style="font-size:0.88em; line-height:1.55;"><strong>Evidence over assertion.</strong> Pass requires <code>file:line</code>. Anything else is the agent telling you what you want to hear.</div>
  </div>

  <div class="card c4" style="display:flex; gap:22px; align-items:center; padding:18px 28px; background:rgba(62,64,71,0.35); border-radius:10px;">
    <div style="font-size:2em; font-weight:800; color:#F46600; min-width:40px; line-height:1; flex-shrink:0;">4</div>
    <div style="font-size:0.88em; line-height:1.55;"><strong>Define criteria before you build.</strong> Acceptance criteria written after implementation anchor on what shipped, not what was needed. That's not a spec — it's a receipt.</div>
  </div>

</div>

---

# Questions?

<div style="margin-top:40px; display:flex; gap:24px;">
  <div class="card c1" style="flex:1; padding:22px; background:rgba(153,51,255,0.08); border:1px solid rgba(153,51,255,0.3); border-radius:10px;">
    <div style="font-size:0.65em; color:#9933FF; text-transform:uppercase; letter-spacing:0.09em; margin-bottom:10px; font-weight:600;">See it in action</div>
    <code style="font-size:0.85em;">sprint complete</code>
    <div style="font-size:0.75em; color:#6F7480; margin-top:8px;">Triggers the eval subagent automatically</div>
  </div>
  <div class="card c2" style="flex:1; padding:22px; background:rgba(62,64,71,0.4); border-radius:10px;">
    <div style="font-size:0.65em; color:#6F7480; text-transform:uppercase; letter-spacing:0.09em; margin-bottom:10px; font-weight:600;">Read the skill</div>
    <code style="font-size:0.85em;">skills/sprint/reference/eval.md</code>
    <div style="font-size:0.75em; color:#6F7480; margin-top:8px;">The full evaluator prompt and grading rubric</div>
  </div>
</div>
